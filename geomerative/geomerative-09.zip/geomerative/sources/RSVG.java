package geomerative;

import processing.core.*;
import processing.xml.*;
import java.lang.*;
import java.io.*;

public class RSVG
{  
  PApplet parent;
  
  /**
   * @invisible
   */
  public void dispose() 
  {
  }  

  //-------------------------------------BEGIN  

  public RSVG(PApplet p)
  {
    initSVG(p);
  }
  
  public void draw(String filename, PGraphics g)
  {
    this.toGroup(filename).draw(g);  
  }
  
  public RGroup toGroup(String filename)
  {
    XMLElement svg = new XMLElement(parent, filename);
    if (!svg.getName().equals("svg")) {
            throw new RuntimeException("root is not <svg>, it's <" + svg.getName() + ">");
    }

    return elemToGroup(svg);
  }

  public RShape toShape(String filename)
  {
    return toGroup(filename).toShape();
  }

  public RPolygon toPolygon(String filename)
  {
    return toGroup(filename).toPolygon();
  }

  public RMesh toMesh(String filename)
  {
    return toGroup(filename).toMesh();
  }

  /**
   * @invisible
   */
  public RGroup elemToGroup(XMLElement element)
  {
    RGroup grp = new RGroup();

    XMLElement elements[] = element.getChildren();

    for (int i = 0; i < elements.length; i++) {
      String name = elements[i].getName();
      //System.out.println("SVG Tag: "+name);
      XMLElement elem = elements[i];
      if(name.equals("g")){
        //System.out.println("Group found");
        grp.addElement(elemToGroup(elem));
      }else if (name.equals("path")) {
        //System.out.println("Path found");
        grp.addElement(elemToShape(elem));
      }else if(name.equals("polygon")){
        //System.out.println("Polygon found");
        RPolygon p = elemToPolyline(elem);
        p.close();
        grp.addElement(p);
      }else if(name.equals("polyline")){
        //System.out.println("Polyline found");
        grp.addElement(elemToPolyline(elem));
      }
    }
    return grp;
  }

  /**
   * @invisible
   */  
  private void initSVG(PApplet p)
  {
    this.parent = p;
    this.parent.registerDispose(this);  
  }  

  /**
   * @invisible
   */
  public RPolygon elemToPolyline(XMLElement elem)
  {
    RPolygon poly = getPolyline(elem.getStringAttribute("points").trim());
    if(elem.hasAttribute("id")){    
      poly.id = elem.getStringAttribute("id");
    }
    return poly;
    
  }

  /**
   * @invisible
   */
  public RShape elemToShape(XMLElement elem)
  {
      RShape shp = getShape(elem.getStringAttribute("d"));
      if(elem.hasAttribute("id")){
        shp.id = elem.getStringAttribute("id");
      }
      return shp;
  }

  /**
   * @invisible
   */
  private RPolygon getPolyline(String s)
  {
    //System.out.println("getPolygon parameter: --------");
    //System.out.println(s);
    RPolygon poly = new RPolygon();
    
    //format string to usable format
    char charline[]=s.toCharArray();
    for(int i=0;i<charline.length;i++)
    {
      switch(charline[i])
      {
      case '-':
        charline=parent.splice(charline,' ',i);
        i++;
        break;   
      case ',':
      case '\n':
      case '\r':
      case '\t':
        charline[i]=' ';
        break;
      }
    }
    String formatted=new String(charline);
    parent.println(formatted);
    String tags[]=parent.splitTokens(formatted,", ");
    parent.println(tags);
    for(int i=0;i<tags.length;i++){
      float x = parent.parseFloat(tags[i]);
      float y = parent.parseFloat(tags[i+1]);
      i++;
      poly.addPoint(x,y);
    }
    return poly;
  }

  /**
   * @invisible
   */
  private RShape getShape(String s)
  {
    //System.out.println("getShape parameter: --------");
    //System.out.println(s);
    RShape shp = new RShape();
    
    //format string to usable format
    char charline[]=s.toCharArray();
    for(int i=0;i<charline.length;i++)
    {
      switch(charline[i])
      {
      case 'M':
      case 'm':
      case 'Z':
      case 'z':
      case 'C':
      case 'c':
      case 'S':
      case 's':
      case 'L':
      case 'l':
      case 'H':
      case 'h':
      case 'V':
      case 'v':
        charline=parent.splice(charline,' ',i);
        i++;
        charline=parent.splice(charline,' ',i+1);
        i++;      
        break;
      case '-':
        charline=parent.splice(charline,' ',i);
        i++;
        break;   
      case ',':
      case '\n':
      case '\r':
      case '\t':
        charline[i]=' ';
        break;
      }
    }
    String formatted=new String(charline);
    //System.out.println(formatted);
    String tags[]=parent.splitTokens(formatted);
    //  println(formatted);
    
    
    //build points
    RPoint curp = new RPoint();
    RPoint relp = new RPoint();
    RPoint refp = new RPoint();
    RPoint strp = new RPoint();

    int numSubshape = 0;
    
    for(int i=0;i<tags.length;i++)
    {
      //System.out.println(tags[i]);
      relp=new RPoint(0f,0f);
      switch(tags[i].charAt(0))
      {
      case 'm':
        relp=new RPoint(curp.x,curp.y);
      case 'M':
        // new subshape
        //System.out.println(tags[i+1]);
        //System.out.println(tags[i+1]);

	numSubshape++;
	shp.addMoveTo(parent.parseFloat(tags[i+1])+relp.x,parent.parseFloat(tags[i+2])+relp.y);
	curp = new RPoint(parent.parseFloat(tags[i+1])+relp.x,parent.parseFloat(tags[i+2])+relp.y);
        refp = new RPoint(curp.x,curp.y);
        strp = new RPoint(curp.x,curp.y);
        i+=2;
        break;

      case 'z':
      case 'Z':
        // close the path
        shp.addLineTo(strp.x,strp.y);
        break;

      case 'c':
        relp=new RPoint(curp.x,curp.y);
      case 'C':
        //System.out.println(tags[i+1]);
        //System.out.println(tags[i+2]);
        //System.out.println(tags[i+3]);
        //System.out.println(tags[i+4]);
        //System.out.println(tags[i+5]);
        //System.out.println(tags[i+6]);

	shp.addBezierTo(parent.parseFloat(tags[i+1])+relp.x,parent.parseFloat(tags[i+2])+relp.y,parent.parseFloat(tags[i+3])+relp.x,parent.parseFloat(tags[i+4])+relp.y,parent.parseFloat(tags[i+5])+relp.x,parent.parseFloat(tags[i+6])+relp.y);
	
        curp=new RPoint(parent.parseFloat(tags[i+5])+relp.x,parent.parseFloat(tags[i+6])+relp.y);
        refp=new RPoint(2.0f*curp.x-(parent.parseFloat(tags[i+3])+relp.x),2.0f*curp.y-(parent.parseFloat(tags[i+4])+relp.y));
        i+=6;
        break;

      case 's':
        relp=new RPoint(curp.x,curp.y);
      case 'S':
        //System.out.println(tags[i+1]);
        //System.out.println(tags[i+2]);
        //System.out.println(tags[i+3]);
        //System.out.println(tags[i+4]);

	shp.addBezierTo(refp.x,refp.y,parent.parseFloat(tags[i+1])+relp.x,parent.parseFloat(tags[i+2])+relp.y,parent.parseFloat(tags[i+3])+relp.x,parent.parseFloat(tags[i+4])+relp.y);
        curp=new RPoint(parent.parseFloat(tags[i+3])+relp.x,parent.parseFloat(tags[i+4])+relp.y);
        refp=new RPoint(2.0f*curp.x-(parent.parseFloat(tags[i+1])+relp.x),2.0f*curp.y-(parent.parseFloat(tags[i+2])+relp.y));
        i+=4;
        break;

      case 'l':
        relp=new RPoint(curp.x,curp.y);
      case 'L':
        //System.out.println(tags[i+1]);
        //System.out.println(tags[i+2]);

	shp.addLineTo(parent.parseFloat(tags[i+1])+relp.x,parent.parseFloat(tags[i+2])+relp.y);
        curp=new RPoint(parent.parseFloat(tags[i+1])+relp.x,parent.parseFloat(tags[i+2])+relp.y);
        refp=new RPoint(curp.x,curp.y);
        i+=2;
        break;

      case 'h':
        relp=new RPoint(curp.x,curp.y);
      case 'H':
        //System.out.println(tags[i+1]);

	shp.addLineTo(parent.parseFloat(tags[i+1])+relp.x,curp.y);
        curp=new RPoint(parent.parseFloat(tags[i+1])+relp.x,curp.y);
        refp=new RPoint(curp.x,curp.y);
        i+=1;
        break;

      case 'v':
        relp=new RPoint(curp.x,curp.y);
      case 'V':
        //System.out.println(tags[i+1]);

	shp.addLineTo(curp.x,parent.parseFloat(tags[i+1])+relp.y);
        curp=new RPoint(curp.x,parent.parseFloat(tags[i+1])+relp.y);
        refp=new RPoint(curp.x,curp.y);
        i+=1;
        break;
      }
    }
    return shp;
  }  
}
